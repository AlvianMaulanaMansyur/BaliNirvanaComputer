
        const toggleBtn = document.querySelector('.toggle_btn')
        const toggleBtnIcon = document.querySelector('.toggle_btn i')
        const dropDownMenu = document.querySelector('.dropdown_menu')
        const searchForm = document.querySelector('.form-search');
        const searchIcon = document.querySelector('.search-icon');
        const searchIconI = document.querySelector('.search-icon i');

        toggleBtn.onclick = function() {
            dropDownMenu.classList.toggle('open')
            const isOpen = dropDownMenu.classList.contains('open')

            toggleBtnIcon.classList = isOpen ?
                'fa-solid fa-x' :
                'fa-solid fa-bars'
        }

        searchIcon.onclick = function() {
            /**
             * cek apakah class name dari icon i adalah x
             * jika iya maka tutup search form dan ubah icon x menjadi icon search
             */
            if (searchIconI.className == 'fa-solid fa-x') {
                searchForm.style.display = 'none';
                searchIconI.className = 'fa-solid fa-search';

                return;
            }
            /**
             * munculkan search form dan ubah
             * search icon menjadi x
             */
            searchForm.style.display = "flex"
            searchIconI.className = 'fa-solid fa-x';
        }